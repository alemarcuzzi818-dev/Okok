package com.lunar.lunarmod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.Item;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.DamageSource;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MoonMod.MODID)
public class OxygenEvents {
    public static final String TAG = "lunar_oxygen";
    public static final int MAX_OXYGEN = 240; // segundos de oxigeno

    private static boolean wearing(PlayerEntity p, EquipmentSlotType slot, Item item) {
        return p.getItemStackFromSlot(slot).getItem() == item;
    }

    private static boolean fullSuit(PlayerEntity p) {
        return wearing(p, EquipmentSlotType.HEAD, ModItems.ASTRONAUT_HELMET.get())
                && wearing(p, EquipmentSlotType.CHEST, ModItems.ASTRONAUT_CHESTPLATE.get())
                && wearing(p, EquipmentSlotType.LEGS, ModItems.ASTRONAUT_LEGGINGS.get())
                && wearing(p, EquipmentSlotType.FEET, ModItems.ASTRONAUT_BOOTS.get());
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        PlayerEntity player = event.player;
        if (event.phase != TickEvent.Phase.END || player.world.isRemote) return;
        if (player.ticksExisted % 20 != 0) return;

        if (player.world.getDimensionKey() != RocketItem.MOON) {
            player.getPersistentData().putInt(TAG, MAX_OXYGEN);
            return;
        }
        // Gravedad baja
        player.addPotionEffect(new EffectInstance(Effects.JUMP_BOOST, 60, 3, false, false));
        player.addPotionEffect(new EffectInstance(Effects.SLOW_FALLING, 60, 0, false, false));

        if (player.isCreative() || player.isSpectator()) return;

        int oxygen = player.getPersistentData().contains(TAG) ? player.getPersistentData().getInt(TAG) : MAX_OXYGEN;
        if (!fullSuit(player)) {
            player.sendStatusMessage(new StringTextComponent("\u00a7cNo puedes respirar! Ponte el traje de astronauta"), true);
            player.attackEntityFrom(DamageSource.DROWN, 2.0f);
            return;
        }
        if (oxygen > 0) {
            oxygen--;
            player.getPersistentData().putInt(TAG, oxygen);
            player.sendStatusMessage(new StringTextComponent("\u00a7bOxigeno: " + oxygen + "/" + MAX_OXYGEN), true);
        } else {
            player.sendStatusMessage(new StringTextComponent("\u00a7cSin oxigeno! Recarga en una estacion"), true);
            player.attackEntityFrom(DamageSource.DROWN, 2.0f);
        }
    }
}
