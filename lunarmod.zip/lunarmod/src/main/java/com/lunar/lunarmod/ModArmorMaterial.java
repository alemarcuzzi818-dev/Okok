package com.lunar.lunarmod;

import java.util.function.Supplier;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.IArmorMaterial;
import net.minecraft.item.Items;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.util.LazyValue;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.SoundEvents;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public enum ModArmorMaterial implements IArmorMaterial {
    ASTRONAUT("lunarmod:astronaut", 25, new int[]{2, 5, 6, 2}, 12, SoundEvents.ITEM_ARMOR_EQUIP_IRON, 1.0f, 0.0f,
            () -> Ingredient.fromItems(Items.IRON_INGOT));

    private static final int[] BASE_DURABILITY = {13, 15, 16, 11};
    private final String name;
    private final int durabilityMultiplier;
    private final int[] defense;
    private final int enchantability;
    private final SoundEvent sound;
    private final float toughness;
    private final float knockback;
    private final LazyValue<Ingredient> repair;

    ModArmorMaterial(String name, int durabilityMultiplier, int[] defense, int enchantability, SoundEvent sound,
                     float toughness, float knockback, Supplier<Ingredient> repair) {
        this.name = name;
        this.durabilityMultiplier = durabilityMultiplier;
        this.defense = defense;
        this.enchantability = enchantability;
        this.sound = sound;
        this.toughness = toughness;
        this.knockback = knockback;
        this.repair = new LazyValue<>(repair);
    }

    @Override public int getDurability(EquipmentSlotType slot) { return BASE_DURABILITY[slot.getIndex()] * durabilityMultiplier; }
    @Override public int getDamageReductionAmount(EquipmentSlotType slot) { return defense[slot.getIndex()]; }
    @Override public int getEnchantability() { return enchantability; }
    @Override public SoundEvent getSoundEvent() { return sound; }
    @Override public Ingredient getRepairMaterial() { return repair.getValue(); }
    @OnlyIn(Dist.CLIENT)
    @Override public String getName() { return name; }
    @Override public float getToughness() { return toughness; }
    @Override public float getKnockbackResistance() { return knockback; }
}
