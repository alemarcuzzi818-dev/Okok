package com.lunar.lunarmod;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;

public class OxygenStationBlock extends Block {
    public OxygenStationBlock(Properties props) {
        super(props);
    }

    @Override
    public ActionResultType onBlockActivated(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockRayTraceResult hit) {
        if (!world.isRemote) {
            player.getPersistentData().putInt(OxygenEvents.TAG, OxygenEvents.MAX_OXYGEN);
            world.playSound(null, pos, SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.BLOCKS, 1.0f, 1.5f);
            player.sendStatusMessage(new StringTextComponent("\u00a7bOxigeno recargado"), true);
        }
        return ActionResultType.SUCCESS;
    }
}
