package com.lunar.lunarmod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.RegistryKey;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;
import net.minecraft.world.gen.Heightmap;
import net.minecraft.world.server.ServerWorld;

public class RocketItem extends Item {
    public static final RegistryKey<World> MOON =
            RegistryKey.getOrCreateKey(Registry.WORLD_KEY, new ResourceLocation(MoonMod.MODID, "moon"));

    public RocketItem(Properties props) {
        super(props);
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (!world.isRemote && player instanceof ServerPlayerEntity) {
            ServerPlayerEntity sp = (ServerPlayerEntity) player;
            MinecraftServer server = sp.getServer();
            boolean onMoon = world.getDimensionKey() == MOON;
            RegistryKey<World> target = onMoon ? World.OVERWORLD : MOON;
            ServerWorld dest = server == null ? null : server.getWorld(target);
            if (dest != null) {
                int x = (int) Math.floor(sp.getPosX());
                int z = (int) Math.floor(sp.getPosZ());
                double y = onMoon ? dest.getHeight(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) + 1 : 64;
                sp.teleport(dest, x + 0.5, y, z + 0.5, sp.rotationYaw, sp.rotationPitch);
                sp.getPersistentData().putInt(OxygenEvents.TAG, OxygenEvents.MAX_OXYGEN);
                sp.getCooldownTracker().setCooldown(this, 60);
            }
        }
        return ActionResult.func_233538_a_(stack, world.isRemote);
    }
}
