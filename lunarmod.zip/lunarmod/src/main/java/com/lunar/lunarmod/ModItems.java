package com.lunar.lunarmod;

import net.minecraft.block.Block;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MoonMod.MODID);

    public static final RegistryObject<Item> MOON_ROCK = ITEMS.register("moon_rock",
            () -> new BlockItem(ModBlocks.MOON_ROCK.get(), new Item.Properties().group(ItemGroup.BUILDING_BLOCKS)));
    public static final RegistryObject<Item> OXYGEN_STATION = ITEMS.register("oxygen_station",
            () -> new BlockItem(ModBlocks.OXYGEN_STATION.get(), new Item.Properties().group(ItemGroup.DECORATIONS)));
    public static final RegistryObject<Item> ROCKET = ITEMS.register("rocket",
            () -> new RocketItem(new Item.Properties().group(ItemGroup.TRANSPORTATION).maxStackSize(1)));

    public static final RegistryObject<Item> ASTRONAUT_HELMET = ITEMS.register("astronaut_helmet",
            () -> new ArmorItem(ModArmorMaterial.ASTRONAUT, EquipmentSlotType.HEAD, new Item.Properties().group(ItemGroup.COMBAT)));
    public static final RegistryObject<Item> ASTRONAUT_CHESTPLATE = ITEMS.register("astronaut_chestplate",
            () -> new ArmorItem(ModArmorMaterial.ASTRONAUT, EquipmentSlotType.CHEST, new Item.Properties().group(ItemGroup.COMBAT)));
    public static final RegistryObject<Item> ASTRONAUT_LEGGINGS = ITEMS.register("astronaut_leggings",
            () -> new ArmorItem(ModArmorMaterial.ASTRONAUT, EquipmentSlotType.LEGS, new Item.Properties().group(ItemGroup.COMBAT)));
    public static final RegistryObject<Item> ASTRONAUT_BOOTS = ITEMS.register("astronaut_boots",
            () -> new ArmorItem(ModArmorMaterial.ASTRONAUT, EquipmentSlotType.FEET, new Item.Properties().group(ItemGroup.COMBAT)));
}
