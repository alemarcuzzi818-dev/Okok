package com.lunar.lunarmod;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MoonMod.MODID);

    public static final RegistryObject<Block> MOON_ROCK = BLOCKS.register("moon_rock",
            () -> new Block(AbstractBlock.Properties.create(Material.ROCK).hardnessAndResistance(1.5f, 6.0f)));

    public static final RegistryObject<Block> OXYGEN_STATION = BLOCKS.register("oxygen_station",
            () -> new OxygenStationBlock(AbstractBlock.Properties.create(Material.IRON).hardnessAndResistance(3.0f, 6.0f).setLightLevel(s -> 8)));
}
